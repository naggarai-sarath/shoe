package com.onlineshoemart.Controller;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.onlineshoemart.model.Products;
import com.onlineshoemart.service.ProductsService;

@RestController
@RequestMapping("/Productsdata")
public class ProductsController {

    @Autowired
    private ProductsService productsService;

    @PostMapping("/create")
    public ResponseEntity<Products> createProducts(@RequestBody Products products) {
        Products createdProducts = productsService.createProducts(products);
        return new ResponseEntity<>(createdProducts, HttpStatus.CREATED);
    }

    @GetMapping("/getAllProducts")
    public ResponseEntity<List<Products>> getAllProducts() {
        List<Products> ProductsList = productsService.getAllProducts();
        if (!ProductsList.isEmpty()) {
            return new ResponseEntity<>(ProductsList, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(Collections.emptyList(), HttpStatus.OK);
        }
    }

    @GetMapping("/getProducts/{id}")
    public ResponseEntity<Products> getProductsById(@PathVariable int product_id) {
        Optional<Products> products = productsService.getProducts(product_id);
        return products.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PutMapping("/updateProducts/{id}")
    public ResponseEntity<Products> updateProducts(@PathVariable int product_id, @RequestBody Products products) {
        Products updatedProducts = productsService.updateProducts(product_id, products);
        if (updatedProducts != null) {
            return new ResponseEntity<>(updatedProducts, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/deleteProducts/{id}")
    public ResponseEntity<Void> deleteProducts(@PathVariable int product_id) {
        productsService.deleteProducts(product_id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
